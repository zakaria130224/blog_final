<div class="clear">
        </div>
        </div>
        <div class="clear">
        </div>
        

<div id="site_info">
       <p>
         &copy; Copyright <a href="#">Software Engineering Project 2016</a>. All Rights Reserved.
        </p>
    </div>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
